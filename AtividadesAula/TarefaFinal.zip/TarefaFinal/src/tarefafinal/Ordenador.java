package tarefafinal;

import java.util.Comparator;
import java.util.List;

public class Ordenador {
    public static boolean bubbleSort(List<Produto> lista, Comparator<Produto> comp, long limiteTempo){
        long inicio = System.nanoTime();
        int n = lista.size();
        
        for(int i=0; i<n-1; i++){
            if(limiteTempo > 0 && (System.nanoTime() - inicio > limiteTempo)){
                return false;
            }
            boolean trocou = false;
            for(int j=0; j<n-1-i; j++){
                if(comp.compare(lista.get(j), lista.get(j+1))>0){
                    Produto temp = lista.get(j);
                    lista.set(j, lista.get(j + 1));
                    lista.set(j+1, temp);
                    trocou = true;
                }
            }
            if(!trocou){
                break;
            }
        }
        return true;
    }
    public static void quickSort(List<Produto> lista, Comparator<Produto> comp){
        if(lista==null || lista.size()<=1){
            return;
        }
        quickSortRecursivo(lista, 0, lista.size()-1, comp);
    }
    private static void quickSortRecursivo(List<Produto> lista, int inicio, int fim, Comparator<Produto> comp){
        if(inicio<fim){
            int Pivo = particionar(lista, inicio, fim, comp);
            quickSortRecursivo(lista, inicio, Pivo-1, comp);
            quickSortRecursivo(lista, Pivo+1, fim, comp);
        }
    } 
    private static int particionar(List<Produto> lista, int inicio, int fim, Comparator<Produto> comp){
        int meio = inicio + (fim-inicio)/2;
        trocar(lista, meio, fim);
        Produto pivo = lista.get(fim);
        int i = inicio -1;        
        for(int j =inicio; j<fim; j++){
            if(comp.compare(lista.get(j), pivo)<=0){
                i++;
                trocar(lista, i, j);
            }
        }
        trocar(lista, i+1, fim);
        return i + 1;
    }
    private static void trocar(List<Produto> lista, int i, int j){
        Produto temp = lista.get(i);
        lista.set(i, lista.get(j));
        lista.set(j, temp);
    }    
}

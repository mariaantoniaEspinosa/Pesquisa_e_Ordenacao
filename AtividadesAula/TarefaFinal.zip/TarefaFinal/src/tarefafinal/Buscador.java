package tarefafinal;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Buscador {
    private HashMap<Integer, Produto> mapaId;
    private HashMap<String, List<Produto>> mapaCategoria;
    
    public Buscador(){
        this.mapaId = new HashMap<>();
        this.mapaCategoria = new HashMap<>();
    }
    public void indices(List<Produto> produtos){
        mapaId.clear();
        mapaCategoria.clear();
        for(Produto p : produtos){
            mapaId.put(p.getId(), p);
            String catKey = p.getCategoria().trim();
            if(!mapaCategoria.containsKey(catKey)){
                mapaCategoria.put(catKey, new ArrayList<>());
            }
            mapaCategoria.get(catKey).add(p);
        }
    }
    public Produto linear(List<Produto> lista, int idBuscado){
        for(Produto p : lista){
            if(p.getId()== idBuscado){
                return p;
            }
        }
        return null;
    }
    public Produto binario(List<Produto> listaId, int idBuscado){
        int inicio = 0;
        int fim = listaId.size() -1;
        while(inicio<= fim){
            int meio = inicio +(fim-inicio)/2;
            int idMeio = listaId.get(meio).getId();
            if(idMeio == idBuscado){
                return listaId.get(meio);
            }
            else if(idMeio < idBuscado){
                inicio = meio + 1;
            }
            else{
                fim = meio -1;
            }
        }
        return null;
    }
    public Produto buscaHashId(int idBuscado){
        return mapaId.get(idBuscado);
    }
    public List<Produto> buscaCategoria(String categoria){
        if(categoria == null) return new ArrayList<>();
        return mapaCategoria.getOrDefault(categoria.trim().toLowerCase(), new ArrayList<>());
    }
}

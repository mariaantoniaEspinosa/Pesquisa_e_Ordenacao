package servidor.model;
import java.util.HashMap;

/**
 * classe para sessões de telefonia
 * @author laboratorio
 */

public class TabelaHash {
    /**
     * sessões é um HashMap com chave celular e conteúdo sendo dados da sessão
     */
    public HashMap<String, Sessao> sessoes;
     
    public TabelaHash(){
        sessoes = new HashMap<>();
    }
}

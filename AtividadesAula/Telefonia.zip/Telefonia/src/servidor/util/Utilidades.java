package servidor.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashMap;

import servidor.model.Sessao;

public class Utilidades {
     
      public static boolean carregarArquivoEmHashMap(String nomeArquivo, HashMap<String, Sessao> sessoes,
              StringBuilder dadosSessoes) {
        try {
            FileReader procurador;
            procurador = new FileReader(nomeArquivo);
            //colocar o conteúdo do arquivo na variável dadoSessoes
            BufferedReader leitor = new BufferedReader(procurador);
            String linha;
            String dadosLinha[];
            Sessao sessao;
            do {
                linha = leitor.readLine();
                dadosLinha = linha.split(";");
                sessao = new Sessao(dadosLinha[0], dadosLinha[1]);
                sessoes.put(sessao.numeroCelular, sessao);
            } while (linha != null);
            leitor.close();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

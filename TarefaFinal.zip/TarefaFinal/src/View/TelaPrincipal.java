/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package View;

/**
 *
 * @author manto
 */

import Model.GeradorRelatorio;
import Model.GerenciadorArquivos;
import Model.Buscador;
import Model.Ordenador;
import Model.Produto;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;



public class TelaPrincipal extends javax.swing.JFrame {
    
    private static final int REPETICOES = 1000;
    private static final long LIMITE_NS = 120_000_000_000L;
    private static final String[] COLUNAS = {"ID", "Nome", "Categoria", "Preço", "Estoque"};

    private final Buscador buscador = new Buscador();
    private ArrayList<Produto> lista = new ArrayList<>();
    private ArrayList<Produto> listaPorId = new ArrayList<>();    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaPrincipal.class.getName());

    /**
     * Creates new form TelaPrincipal
     */
    public TelaPrincipal() {
        initComponents();
        setLocationRelativeTo(null);
        tblProdutos.setDefaultEditor(Object.class, null); 
        btnCarregarActionPerformed(null);
    }
    private void preencherTabela(List<Produto> produtos) {
        Object[][] dados = new Object[produtos.size()][];
        for (int i = 0; i < dados.length; i++) {
            Produto p = produtos.get(i);
            dados[i] = new Object[]{p.getId(), p.getNome(), p.getCategoria(), p.getPreco(), p.getEstoque()};
        }
        ((DefaultTableModel) tblProdutos.getModel()).setDataVector(dados, COLUNAS);
    }

    private void erro(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Erro", JOptionPane.ERROR_MESSAGE);
    }  
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        cbArquivo = new javax.swing.JComboBox<>();
        btnCarregar = new javax.swing.JButton();
        btnExportar = new javax.swing.JButton();
        btnRelatorio = new javax.swing.JButton();
        cbCampo = new javax.swing.JComboBox<>();
        cbAlgoritmo = new javax.swing.JComboBox<>();
        btnOrdenar = new javax.swing.JButton();
        cbBusca = new javax.swing.JComboBox<>();
        txtBusca = new javax.swing.JTextField();
        btbBuscarId = new javax.swing.JButton();
        btnBuscarCategoria = new javax.swing.JButton();
        lblTempo = new javax.swing.JLabel();
        btnTodos = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblProdutos = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        cbArquivo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "produtos_1000.txt", "produtos_10000.txt", "produtos_50000.txt" }));
        cbArquivo.addActionListener(this::cbArquivoActionPerformed);

        btnCarregar.setText("Carregar");
        btnCarregar.addActionListener(this::btnCarregarActionPerformed);

        btnExportar.setText("Exportar");
        btnExportar.addActionListener(this::btnExportarActionPerformed);

        btnRelatorio.setText("Relatorio");
        btnRelatorio.addActionListener(this::btnRelatorioActionPerformed);

        cbCampo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Nome", "Preco" }));

        cbAlgoritmo.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bubble Sort", "Quick Sort", "Collections.sort", " " }));
        cbAlgoritmo.addActionListener(this::cbAlgoritmoActionPerformed);

        btnOrdenar.setText("Ordenar");
        btnOrdenar.addActionListener(this::btnOrdenarActionPerformed);

        cbBusca.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Linear", "Binária", "HashMap" }));

        btbBuscarId.setText("Busca por Id");
        btbBuscarId.addActionListener(this::btbBuscarIdActionPerformed);

        btnBuscarCategoria.setText("Busca por Categoria");
        btnBuscarCategoria.addActionListener(this::btnBuscarCategoriaActionPerformed);

        lblTempo.setText("Tempo da última operação -");

        btnTodos.setText("Lista Completa");
        btnTodos.addActionListener(this::btnTodosActionPerformed);

        jLabel1.setText("Escolha o .txt:");

        jLabel2.setText("Selecione o método de ordenação:");

        jLabel3.setText("Selecione a técnica de busca:");

        jLabel4.setText("Digite o ID ou categoria:");

        tblProdutos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5"
            }
        ));
        jScrollPane2.setViewportView(tblProdutos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(164, 164, 164)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(192, 192, 192)
                        .addComponent(lblTempo)
                        .addGap(366, 366, 366))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(cbBusca, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(cbCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btnOrdenar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cbAlgoritmo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cbArquivo, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGap(17, 17, 17))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btbBuscarId, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnBuscarCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnTodos, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtBusca, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnCarregar, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnExportar, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnRelatorio, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2))
                        .addGap(169, 169, 169))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbArquivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnCarregar)
                    .addComponent(btnExportar)
                    .addComponent(btnRelatorio))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbAlgoritmo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbBusca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnOrdenar))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtBusca, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btbBuscarId)
                    .addComponent(btnBuscarCategoria)
                    .addComponent(btnTodos))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTempo)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbArquivoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbArquivoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbArquivoActionPerformed

    private void btnCarregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCarregarActionPerformed
    try {
        lista = GerenciadorArquivos.lerProdutos((String) cbArquivo.getSelectedItem());
        buscador.indices(lista);
        listaPorId = new ArrayList<>(lista);
        Ordenador.quickSort(listaPorId, Ordenador.POR_ID);
        preencherTabela(lista);
        lblTempo.setText(lista.size() + " produtos carregados");
    } catch (IOException | RuntimeException ex) {
        erro("Não foi possível ler o arquivo: " + ex.getMessage());
        }      
    }//GEN-LAST:event_btnCarregarActionPerformed

    private void btnExportarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExportarActionPerformed
        JFileChooser fc = new JFileChooser(new File("."));
        fc.setSelectedFile(new File("produtos_exportados.txt"));
        if (fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                GerenciadorArquivos.exportarProdutos(fc.getSelectedFile().getPath(), lista);
                lblTempo.setText("Lista exportada para " + fc.getSelectedFile().getName());
            } catch (IOException ex) {
                erro("Erro ao exportar: " + ex.getMessage());
            }
        }
    }//GEN-LAST:event_btnExportarActionPerformed

    private void btnOrdenarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrdenarActionPerformed
    final Comparator<Produto> comp = cbCampo.getSelectedIndex() == 0 ? Ordenador.POR_NOME : Ordenador.POR_PRECO;
    final int alg = cbAlgoritmo.getSelectedIndex();
    btnOrdenar.setEnabled(false);
    lblTempo.setText("Ordenando...");

    new SwingWorker<String, Void>() {
        @Override
        protected String doInBackground() {
            long ini = System.nanoTime();
            boolean concluiu = true;
            switch (alg) {
                case 0: concluiu = Ordenador.bubbleSort(lista, comp, LIMITE_NS); break;
                case 1: Ordenador.quickSort(lista, comp); break;
                default: lista.sort(comp);
            }
            long t = System.nanoTime() - ini;
            return concluiu ? "Tempo da ordenação: " + GeradorRelatorio.formatar(t)
                            : "não concluído (> 2 min)";
        }

        @Override
        protected void done() {
            try {
                lblTempo.setText(get());
            } catch (Exception ex) {
                erro("Erro ao ordenar: " + ex.getMessage());
            }
            preencherTabela(lista);
            btnOrdenar.setEnabled(true);
            }
        }
        .execute();
    }//GEN-LAST:event_btnOrdenarActionPerformed

    private void btbBuscarIdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btbBuscarIdActionPerformed
    int id;
    try {
        id = Integer.parseInt(txtBusca.getText().trim());
    } catch (NumberFormatException ex) {
        erro("Informe um id numérico.");
        return;
    }
    Buscador.BuscaId busca;
    switch (cbBusca.getSelectedIndex()) {
        case 0:  busca = i -> buscador.linear(lista, i); break;
        case 1:  busca = i -> buscador.binario(listaPorId, i); break;
        default: busca = buscador::buscaHashId;
    }
    Produto achado = null;
    long ini = System.nanoTime();
    for (int r = 0; r < REPETICOES; r++) {
        achado = busca.buscar(id);
    }
    long media = (System.nanoTime() - ini) / REPETICOES;

    List<Produto> resultado = new ArrayList<>();
    if (achado != null) resultado.add(achado);
    preencherTabela(resultado);
    lblTempo.setText((achado == null ? "Id não encontrado" : "Produto encontrado")
            + " - busca " + cbBusca.getSelectedItem() + ": tempo médio de "
            + GeradorRelatorio.formatar(media) + " (" + REPETICOES + " repetições)");
    }//GEN-LAST:event_btbBuscarIdActionPerformed

    private void btnBuscarCategoriaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarCategoriaActionPerformed
    String cat = txtBusca.getText().trim();
    List<Produto> res = null;
    long ini = System.nanoTime();
    for (int r = 0; r < REPETICOES; r++) {
        res = buscador.buscaCategoria(cat);
    }
    long media = (System.nanoTime() - ini) / REPETICOES;
    preencherTabela(res);
    lblTempo.setText(res.size() + " produtos na categoria - HashMap: tempo médio de "
            + GeradorRelatorio.formatar(media) + " (" + REPETICOES + " repetições)");
    }//GEN-LAST:event_btnBuscarCategoriaActionPerformed

    private void btnRelatorioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRelatorioActionPerformed
   btnRelatorio.setEnabled(false);
   lblTempo.setText("Gerando relatório (pode levar alguns segundos)...");
   new SwingWorker<Void, Void>() {
       @Override
       protected Void doInBackground() throws Exception {
           GeradorRelatorio.gerar(".", "relatorio.txt");
           return null;
       }

       @Override
       protected void done() {
           try {
               get();
               lblTempo.setText("relatorio.txt gerado na pasta do projeto");
           } catch (Exception ex) {
               erro("Erro ao gerar relatório: " + ex.getMessage());
           }
           btnRelatorio.setEnabled(true);
       }
   }.execute();
    }//GEN-LAST:event_btnRelatorioActionPerformed

    private void btnTodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTodosActionPerformed
        preencherTabela(lista);
    }//GEN-LAST:event_btnTodosActionPerformed

    private void cbAlgoritmoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbAlgoritmoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbAlgoritmoActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TelaPrincipal().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btbBuscarId;
    private javax.swing.JButton btnBuscarCategoria;
    private javax.swing.JButton btnCarregar;
    private javax.swing.JButton btnExportar;
    private javax.swing.JButton btnOrdenar;
    private javax.swing.JButton btnRelatorio;
    private javax.swing.JButton btnTodos;
    private javax.swing.JComboBox<String> cbAlgoritmo;
    private javax.swing.JComboBox<String> cbArquivo;
    private javax.swing.JComboBox<String> cbBusca;
    private javax.swing.JComboBox<String> cbCampo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblTempo;
    private javax.swing.JTable tblProdutos;
    private javax.swing.JTextField txtBusca;
    // End of variables declaration//GEN-END:variables
}

package Model;

import Model.GerenciadorArquivos;
import Model.Buscador;
import Model.Ordenador;
import Model.Produto;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

public class GeradorRelatorio {

    private static final int[] TAMANHOS = {1000, 10000, 50000};
    private static final int REPETICOES = 1000;
    private static final long LIMITE_NS = 120_000_000_000L; // 2 minutos
    private static final Locale BR = Locale.forLanguageTag("pt-BR");

/**
* Para cada tamanho (1.000, 10.000 e 50.000), lê o arquivo da pasta e mede
* Bubble Sort, Quick Sort (por preço), busca linear, binária e por HashMap
* (média de 1.000 buscas) e a construção do HashMap. Depois grava a tabela
* e a análise em 'destino'. Se o Bubble passar de 2 minutos, registra
* "não concluído". Lança IOException se não conseguir ler ou gravar.
*/
    
    public static void gerar(String pasta, String destino) throws IOException {
        String[][] tab = new String[6][TAMANHOS.length];
        double[] linear = new double[TAMANHOS.length];
        double[] hash = new double[TAMANHOS.length];
        double[] construcao = new double[TAMANHOS.length];

        for (int c = 0; c < TAMANHOS.length; c++) {
            int n = TAMANHOS[c];
            ArrayList<Produto> base = GerenciadorArquivos.lerProdutos(
                    new File(pasta, "produtos_" + n + ".txt").getPath());

            ArrayList<Produto> copia = new ArrayList<>(base);
            long ini = System.nanoTime();
            boolean concluiu = Ordenador.bubbleSort(copia, Ordenador.POR_PRECO, LIMITE_NS);
            long t = System.nanoTime() - ini;
            tab[0][c] = concluiu ? formatar(t) : "não concluído (> 2 min)";

            copia = new ArrayList<>(base);
            ini = System.nanoTime();
            Ordenador.quickSort(copia, Ordenador.POR_PRECO);
            t = System.nanoTime() - ini;
            tab[1][c] = formatar(t);

            ArrayList<Produto> porId = new ArrayList<>(base);
            Ordenador.quickSort(porId, Ordenador.POR_ID);

            Random rnd = new Random(42);
            int[] ids = new int[REPETICOES];
            for (int i = 0; i < ids.length; i++) {
                ids[i] = base.get(rnd.nextInt(base.size())).getId();
            }

            Buscador b = new Buscador();
            b.construirIndiceId(base);               
            ini = System.nanoTime();
            b.construirIndiceId(base);            
            construcao[c] = System.nanoTime() - ini;

            linear[c] = mediaNs(id -> b.linear(base, id), ids);
            double binaria = mediaNs(id -> b.binario(porId, id), ids);
            hash[c] = mediaNs(b::buscaHashId, ids);

            tab[2][c] = formatar(linear[c]);
            tab[3][c] = formatar(binaria);
            tab[4][c] = formatar(hash[c]);
            tab[5][c] = formatar(construcao[c]);
        }

        String[] nomes = {
            "Ordenação simples (por preço)", "Ordenação eficiente (por preço)",
            "Busca linear por id (média)", "Busca binária por id (média)",
            "Busca por HashMap (média)", "Construção do HashMap"
        };

        try (BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream(destino), StandardCharsets.UTF_8))) {
            bw.write("RELATÓRIO DE TEMPOS - Pesquisa e Ordenação");
            bw.newLine();
            bw.write("(buscas: média de " + REPETICOES + " consultas; mesmos ids nas 3 técnicas)");
            bw.newLine();
            bw.newLine();
            bw.write(String.format("%-34s | %-24s | %-24s | %-24s", "Operação", "1.000", "10.000", "50.000"));
            bw.newLine();
            bw.write("-".repeat(34 + 3 * 27));
            bw.newLine();
            for (int i = 0; i < nomes.length; i++) {
                bw.write(String.format("%-34s | %-24s | %-24s | %-24s", nomes[i], tab[i][0], tab[i][1], tab[i][2]));
                bw.newLine();
            }
            bw.newLine();

            int u = TAMANHOS.length - 1;
            double ganho = linear[u] - hash[u];
            String equilibrio = ganho > 0
                    ? "cerca de " + (long) Math.ceil(construcao[u] / ganho) + " buscas"
                    : "n/d";
            bw.write("ANÁLISE");
            bw.newLine();
            bw.write("1) A busca por HashMap foi a mais rápida: acesso em tempo praticamente constante, O(1).");
            bw.newLine();
            bw.write("2) A binária vem em seguida, O(log n), mas exige a lista ordenada; a linear é O(n) e cresce com o arquivo.");
            bw.newLine();
            bw.write("3) O HashMap custa tempo O(n) e memória extra para ser montado (50.000 registros: "
                    + formatar(construcao[u]) + ").");
            bw.newLine();
            bw.write("4) Esse custo se paga a partir de " + equilibrio + " (50.000 registros, em relação à linear).");
            bw.newLine();
            bw.write("5) Vale a pena quando há muitas consultas sobre os mesmos dados; para uma busca única, a linear basta.");
            bw.newLine();
        }
    }

/**
* Devolve o tempo médio (em ns) de uma busca. Roda uma vez para aquecer a
* JVM e outra para medir, usando um id de cada vez do vetor.
*/
    
    private static double mediaNs(Buscador.BuscaId busca, int[] ids) {
        long soma = 0;
        for (int id : ids) { 
            Produto p = busca.buscar(id);
            if (p != null) soma += p.getId();
        }
        long ini = System.nanoTime();
        for (int id : ids) {
            Produto p = busca.buscar(id);
            if (p != null) soma += p.getId();
        }
        long fim = System.nanoTime();
        if (soma == Long.MIN_VALUE) System.out.print(""); 
        return (fim - ini) / (double) ids.length;
    }

/** Converte um tempo em ns para texto na melhor unidade (ns, µs ou ms). */
    
    public static String formatar(double ns) {
        if (ns >= 1_000_000) return String.format(BR, "%.2f ms", ns / 1_000_000);
        if (ns >= 1_000) return String.format(BR, "%.2f µs", ns / 1_000);
        return String.format(BR, "%.0f ns", ns);
    }
}
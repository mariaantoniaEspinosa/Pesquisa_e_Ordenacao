package Model;

import Model.Produto;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Buscador {

/** Representa uma busca por id, para medir qualquer técnica da mesma forma. */
    
    public interface BuscaId {
        Produto buscar(int id);
    }

    private final HashMap<Integer, Produto> mapaId = new HashMap<>();
    private final HashMap<String, List<Produto>> mapaCategoria = new HashMap<>();

/** Monta os dois índices (por id e por categoria) na carga dos dados. */
    
    public void indices(List<Produto> produtos) {
        construirIndiceId(produtos);
        construirIndiceCategoria(produtos);
    }

/**
* Monta o HashMap de id para produto. Fica separado para o relatório
* poder medir só o tempo de construção desse índice.
*/
    
    public void construirIndiceId(List<Produto> produtos) {
        mapaId.clear();
        for (Produto p : produtos) {
            mapaId.put(p.getId(), p);
        }
    }

/** Monta o HashMap de categoria (em minúsculas) para a lista de produtos dela. */
    
    public void construirIndiceCategoria(List<Produto> produtos) {
        mapaCategoria.clear();
        for (Produto p : produtos) {
            String chave = p.getCategoria().trim().toLowerCase();
            mapaCategoria.computeIfAbsent(chave, k -> new ArrayList<>()).add(p);
        }
    }
    
/** Busca linear: percorre a lista do início até achar o id. Devolve null se não achar. */
    
    public Produto linear(List<Produto> lista, int idBuscado) {
        for (Produto p : lista) {
            if (p.getId() == idBuscado) {
                return p;
            }
        }
        return null;
    }

/**
* Busca binária pelo id: divide a lista ao meio a cada passo. A lista
* recebida PRECISA estar ordenada por id. Devolve null se não achar.
*/
    
    public Produto binario(List<Produto> listaId, int idBuscado) {
        int inicio = 0;
        int fim = listaId.size() - 1;
        while (inicio <= fim) {
            int meio = inicio + (fim - inicio) / 2;
            int idMeio = listaId.get(meio).getId();
            if (idMeio == idBuscado) {
                return listaId.get(meio);
            } else if (idMeio < idBuscado) {
                inicio = meio + 1;
            } else {
                fim = meio - 1;
            }
        }
        return null;
    }

/** Busca pelo id consultando o HashMap. Devolve null se não achar. */
    
    public Produto buscaHashId(int idBuscado) {
        return mapaId.get(idBuscado);
    }

/**
* Devolve os produtos da categoria (sem diferenciar maiúsculas de
* minúsculas) consultando o HashMap. Devolve lista vazia se não houver.
*/
    
    public List<Produto> buscaCategoria(String categoria) {
        if (categoria == null) return new ArrayList<>();
        // a chave do mapa está em minúsculas, então a consulta também precisa estar
        return mapaCategoria.getOrDefault(categoria.trim().toLowerCase(), new ArrayList<>());
    }
}
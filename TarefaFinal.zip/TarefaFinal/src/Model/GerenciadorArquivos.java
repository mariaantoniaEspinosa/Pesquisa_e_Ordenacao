package Model;

import Model.Produto;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Lê e grava os arquivos texto de produtos. */

public class GerenciadorArquivos {
    
/**
* Lê o arquivo (UTF-8), ignora o cabeçalho e as linhas vazias, separa os
* campos por ";" e devolve uma lista de Produto. Lança IOException se não
* conseguir ler o arquivo.
*/
    
    public static ArrayList<Produto> lerProdutos(String caminho) throws IOException{
        ArrayList<Produto> lista = new ArrayList<>();
        try(BufferedReader br = new BufferedReader (new InputStreamReader(new FileInputStream(caminho), StandardCharsets.UTF_8))){
            String linha = br.readLine();
            while((linha = br.readLine()) != null){
                if(linha.trim().isEmpty()) continue;
                String[] partes = linha.split(";");
                int id = Integer.parseInt(partes[0].trim());
                String nome = partes[1].trim();
                String categoria = partes[2].trim();
                double preco = Double.parseDouble(partes[3].trim());
                int estoque = Integer.parseInt(partes[4].trim());
                lista.add(new Produto(id, nome, categoria, preco, estoque));
            }
        }
        return lista;
    }
    
/**
* Grava a lista, na ordem atual, em um arquivo texto (UTF-8) com o
* cabeçalho e uma linha por produto. Lança IOException se não conseguir
* gravar.
*/
    
    public static void exportarProdutos(String destino, List<Produto> lista) throws IOException{
        try(BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(destino), StandardCharsets.UTF_8))){
            bw.write("id;nome;categoria;preco;estoque");
            bw.newLine();
            for(Produto p : lista){
                bw.write(p.toString());
                bw.newLine();
            }
        }
    }
}
